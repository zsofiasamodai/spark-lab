import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { transformTask, generateIllustration } from "./services/openai";
import { insertFolderSchema, insertPromptSchema, insertTaskSchema } from "@shared/schema";
import multer from "multer";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Folder routes
  app.get('/api/folders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const folders = await storage.getFoldersByUserId(userId);
      res.json(folders);
    } catch (error) {
      console.error("Error fetching folders:", error);
      res.status(500).json({ message: "Failed to fetch folders" });
    }
  });

  app.post('/api/folders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const folderData = insertFolderSchema.parse({ ...req.body, userId });
      const folder = await storage.createFolder(folderData);
      res.json(folder);
    } catch (error) {
      console.error("Error creating folder:", error);
      res.status(400).json({ message: "Failed to create folder" });
    }
  });

  app.put('/api/folders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updateData = insertFolderSchema.partial().parse(req.body);
      const folder = await storage.updateFolder(id, updateData);
      res.json(folder);
    } catch (error) {
      console.error("Error updating folder:", error);
      res.status(400).json({ message: "Failed to update folder" });
    }
  });

  app.delete('/api/folders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteFolder(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting folder:", error);
      res.status(500).json({ message: "Failed to delete folder" });
    }
  });

  // Prompt routes
  app.get('/api/prompts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const prompts = await storage.getPromptsByUserId(userId);
      res.json(prompts);
    } catch (error) {
      console.error("Error fetching prompts:", error);
      res.status(500).json({ message: "Failed to fetch prompts" });
    }
  });

  app.post('/api/prompts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const promptData = insertPromptSchema.parse({ ...req.body, userId });
      const prompt = await storage.createPrompt(promptData);
      res.json(prompt);
    } catch (error) {
      console.error("Error creating prompt:", error);
      res.status(400).json({ message: "Failed to create prompt" });
    }
  });

  app.delete('/api/prompts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deletePrompt(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting prompt:", error);
      res.status(500).json({ message: "Failed to delete prompt" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { folderId, recent } = req.query;
      
      let tasks;
      if (folderId) {
        tasks = await storage.getTasksByFolderId(folderId as string);
      } else if (recent) {
        tasks = await storage.getRecentTasksByUserId(userId, parseInt(recent as string) || 10);
      } else {
        tasks = await storage.getTasksByUserId(userId);
      }
      
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskData = insertTaskSchema.parse({ ...req.body, userId });
      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(400).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updateData = insertTaskSchema.partial().parse(req.body);
      const task = await storage.updateTask(id, updateData);
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(400).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTask(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // AI transformation route
  app.post('/api/tasks/transform', isAuthenticated, async (req: any, res) => {
    try {
      const { originalText, context, includeRealLifeExamples } = req.body;
      
      if (!originalText || !context) {
        return res.status(400).json({ message: "Original text and context are required" });
      }

      if (context.length < 10 || context.length > 1000) {
        return res.status(400).json({ message: "Context must be between 10 and 1000 characters" });
      }

      const result = await transformTask({ 
        originalText, 
        context, 
        includeRealLifeExamples: includeRealLifeExamples || false 
      });
      res.json(result);
    } catch (error: any) {
      console.error("Error transforming task:", error);
      
      const errorMessage = error.message || "Failed to transform task";
      
      // Handle specific error types
      if (errorMessage.startsWith("QUOTA_EXCEEDED:")) {
        return res.status(429).json({ 
          message: errorMessage.replace("QUOTA_EXCEEDED: ", ""),
          type: "quota_exceeded" 
        });
      }
      
      if (errorMessage.startsWith("INVALID_API_KEY:")) {
        return res.status(401).json({ 
          message: errorMessage.replace("INVALID_API_KEY: ", ""),
          type: "invalid_api_key" 
        });
      }
      
      if (errorMessage.startsWith("SERVICE_UNAVAILABLE:")) {
        return res.status(503).json({ 
          message: errorMessage.replace("SERVICE_UNAVAILABLE: ", ""),
          type: "service_unavailable" 
        });
      }
      
      if (errorMessage.startsWith("AI_ERROR:")) {
        return res.status(422).json({ 
          message: errorMessage.replace("AI_ERROR: ", ""),
          type: "ai_processing_error" 
        });
      }
      
      res.status(500).json({ message: "Nem sikerült átalakítani a feladatot." });
    }
  });

  // Illustration generation route
  app.post('/api/tasks/generate-illustration', isAuthenticated, async (req: any, res) => {
    try {
      const { taskText, style, customDescription } = req.body;
      
      if (!taskText) {
        return res.status(400).json({ message: "Task text is required" });
      }

      const result = await generateIllustration({ 
        taskText, 
        style: style || 'cartoon', 
        customDescription 
      });
      res.json(result);
    } catch (error: any) {
      console.error("Error generating illustration:", error);
      
      const errorMessage = error.message || "Failed to generate illustration";
      
      // Handle specific error types
      if (errorMessage.startsWith("QUOTA_EXCEEDED:")) {
        return res.status(429).json({ 
          message: errorMessage.replace("QUOTA_EXCEEDED: ", ""),
          type: "quota_exceeded" 
        });
      }
      
      if (errorMessage.startsWith("INVALID_API_KEY:")) {
        return res.status(401).json({ 
          message: errorMessage.replace("INVALID_API_KEY: ", ""),
          type: "invalid_api_key" 
        });
      }
      
      if (errorMessage.startsWith("SERVICE_UNAVAILABLE:")) {
        return res.status(503).json({ 
          message: errorMessage.replace("SERVICE_UNAVAILABLE: ", ""),
          type: "service_unavailable" 
        });
      }
      
      if (errorMessage.startsWith("AI_ERROR:")) {
        return res.status(422).json({ 
          message: errorMessage.replace("AI_ERROR: ", ""),
          type: "ai_processing_error" 
        });
      }
      
      res.status(500).json({ message: "Nem sikerült generálni az illusztrációt." });
    }
  });

  // Statistics route
  app.get('/api/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const [allTasks, folders] = await Promise.all([
        storage.getTasksByUserId(userId),
        storage.getFoldersByUserId(userId)
      ]);

      const stats = {
        totalTasks: allTasks.length,
        totalFolders: folders.length,
        aiTransformations: allTasks.filter(task => task.transformedText).length
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
