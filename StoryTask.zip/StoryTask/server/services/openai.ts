import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR 
});

export interface TransformTaskRequest {
  originalText: string;
  context: string;
  includeRealLifeExamples?: boolean;
}

export interface TransformTaskResponse {
  transformedText: string;
  preservedElements: string[];
}

export interface GenerateIllustrationRequest {
  taskText: string;
  style: 'cartoon' | 'realistic';
  customDescription?: string;
}

export interface GenerateIllustrationResponse {
  imageUrl: string;
}

export async function transformTask({ originalText, context, includeRealLifeExamples }: TransformTaskRequest): Promise<TransformTaskResponse> {
  try {
    const realLifeExamplesInstruction = includeRealLifeExamples 
      ? `
6. ADDITIONALLY: After the transformed exercise, include a section titled "## Valós életbeli alkalmazások" followed by 2-3 konkrét examples showing how this mathematical concept applies in real-life situations. Each example should be practical, relatable, and age-appropriate. Format each example as a separate paragraph with clear structure.`
      : '';

    const prompt = `
You are an educational content transformer. Your task is to transform the given educational exercise while preserving all numerical data, mathematical formulas, and the core learning objectives.

CRITICAL REQUIREMENTS:
1. Keep ALL numbers, calculations, formulas, and mathematical content EXACTLY the same
2. Preserve the educational difficulty level and learning objectives
3. Only change the narrative context, characters, and setting
4. Maintain the same question structure and answer format
5. Ensure the transformed content is appropriate for school use${realLifeExamplesInstruction}

Context to apply: ${context}

Original exercise:
${originalText}

Please transform this exercise and respond with JSON in this exact format:
{
  "transformedText": "The transformed exercise text here${includeRealLifeExamples ? ' (including the real-life examples section if requested)' : ''}",
  "preservedElements": ["list of", "preserved mathematical", "elements"]
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are an expert educational content transformer specialized in maintaining mathematical accuracy while changing narrative contexts."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    if (!result.transformedText) {
      throw new Error("Invalid response from AI service");
    }

    return {
      transformedText: result.transformedText,
      preservedElements: result.preservedElements || []
    };
  } catch (error: any) {
    console.error("Error transforming task:", error);
    
    // Handle specific OpenAI errors
    if (error.status === 429) {
      throw new Error("QUOTA_EXCEEDED: Az OpenAI API kvóta kimerült. Kérjük, ellenőrizze a számlázási adatokat.");
    }
    
    if (error.status === 401) {
      throw new Error("INVALID_API_KEY: Érvénytelen API kulcs.");
    }
    
    if (error.status >= 500) {
      throw new Error("SERVICE_UNAVAILABLE: Az AI szolgáltatás átmenetileg nem elérhető. Próbálja meg később.");
    }
    
    throw new Error("AI_ERROR: " + (error.message || "Ismeretlen hiba történt az AI feldolgozás során."));
  }
}

export async function generateIllustration({ taskText, style, customDescription }: GenerateIllustrationRequest): Promise<GenerateIllustrationResponse> {
  try {
    const stylePrompt = style === 'cartoon' 
      ? "cartoon style, colorful, educational, child-friendly illustration" 
      : "realistic educational illustration, clean and professional";
    
    const description = customDescription || `Educational illustration for: ${taskText.substring(0, 200)}...`;
    
    const prompt = `${description}. Style: ${stylePrompt}. The image should be appropriate for educational use in schools.`;

    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    if (!response.data || !response.data[0]?.url) {
      throw new Error("No image generated");
    }

    return {
      imageUrl: response.data[0].url
    };
  } catch (error: any) {
    console.error("Error generating illustration:", error);
    
    // Handle specific OpenAI errors
    if (error.status === 429) {
      throw new Error("QUOTA_EXCEEDED: Az OpenAI API kvóta kimerült. Kérjük, ellenőrizze a számlázási adatokat.");
    }
    
    if (error.status === 401) {
      throw new Error("INVALID_API_KEY: Érvénytelen API kulcs.");
    }
    
    if (error.status >= 500) {
      throw new Error("SERVICE_UNAVAILABLE: Az AI szolgáltatás átmenetileg nem elérhető. Próbálja meg később.");
    }
    
    throw new Error("AI_ERROR: " + (error.message || "Ismeretlen hiba történt az illusztráció generálása során."));
  }
}
