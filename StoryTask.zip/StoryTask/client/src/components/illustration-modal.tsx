import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Palette, Image as ImageIcon, X, Wand2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

interface IllustrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskText: string;
  onIllustrationGenerated: (url: string) => void;
}

export default function IllustrationModal({ 
  isOpen, 
  onClose, 
  taskText, 
  onIllustrationGenerated 
}: IllustrationModalProps) {
  const [selectedStyle, setSelectedStyle] = useState<'cartoon' | 'realistic'>('cartoon');
  const [customDescription, setCustomDescription] = useState("");
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const { toast } = useToast();

  // Generate illustration mutation
  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tasks/generate-illustration", {
        taskText,
        style: selectedStyle,
        customDescription: customDescription || undefined,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedImageUrl(data.imageUrl);
      onIllustrationGenerated(data.imageUrl);
      toast({
        title: "Illusztráció generálva",
        description: "Az illusztráció sikeresen elkészült!",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      // Parse error message for better user feedback
      const errorMessage = error.message || "";
      let title = "Generálási hiba";
      let description = "Nem sikerült generálni az illusztrációt. Próbálja meg újra.";
      
      if (errorMessage.includes("429:")) {
        title = "API kvóta kimerült";
        description = "Az OpenAI API kvóta kimerült. Kérjük, ellenőrizze a számlázási adatokat, vagy próbálja meg később.";
      } else if (errorMessage.includes("quota")) {
        title = "API kvóta kimerült";
        description = "Az AI szolgáltatás kvótája kimerült. Próbálja meg később vagy ellenőrizze az API beállításokat.";
      } else if (errorMessage.includes("503:") || errorMessage.includes("SERVICE_UNAVAILABLE")) {
        title = "Szolgáltatás nem elérhető";
        description = "Az AI szolgáltatás átmenetileg nem elérhető. Próbálja meg néhány perc múlva.";
      } else if (errorMessage.includes("401:") || errorMessage.includes("INVALID_API_KEY")) {
        title = "API kulcs hiba";
        description = "Az API kulcs érvénytelen vagy lejárt. Kérjük, ellenőrizze a beállításokat.";
      }
      
      toast({
        title,
        description,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    generateMutation.mutate();
  };

  const handleDownload = () => {
    if (generatedImageUrl) {
      const link = document.createElement('a');
      link.href = generatedImageUrl;
      link.download = 'illustration.png';
      link.click();
    }
  };

  const handleClose = () => {
    setGeneratedImageUrl(null);
    setCustomDescription("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Illusztráció Generálása
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Style Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Illusztráció stílusa
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div 
                onClick={() => setSelectedStyle('cartoon')}
                className={`border-2 rounded-lg p-3 cursor-pointer transition-colors ${
                  selectedStyle === 'cartoon' 
                    ? 'border-blue-600 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-center">
                  <Palette className={`mx-auto mb-2 h-6 w-6 ${
                    selectedStyle === 'cartoon' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <p className={`text-sm font-medium ${
                    selectedStyle === 'cartoon' ? 'text-blue-700' : 'text-gray-600'
                  }`}>
                    Rajzfilm stílus
                  </p>
                </div>
              </div>
              
              <div 
                onClick={() => setSelectedStyle('realistic')}
                className={`border-2 rounded-lg p-3 cursor-pointer transition-colors ${
                  selectedStyle === 'realistic' 
                    ? 'border-blue-600 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-center">
                  <ImageIcon className={`mx-auto mb-2 h-6 w-6 ${
                    selectedStyle === 'realistic' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <p className={`text-sm font-medium ${
                    selectedStyle === 'realistic' ? 'text-blue-700' : 'text-gray-600'
                  }`}>
                    Realisztikus
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Custom Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Egyéni leírás (opcionális)
            </label>
            <Textarea 
              placeholder="Adja meg az illusztráció részletes leírását..."
              value={customDescription}
              onChange={(e) => setCustomDescription(e.target.value)}
              className="h-24 resize-none"
            />
          </div>

          {/* Generated Illustration */}
          {generatedImageUrl && (
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-3">
                Generált illusztráció:
              </h4>
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 text-center">
                <img 
                  src={generatedImageUrl}
                  alt="AI által generált illusztráció" 
                  className="w-full max-h-64 object-contain rounded-lg mb-3"
                />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleDownload}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Letöltés
                </Button>
              </div>
            </div>
          )}

          {/* Generation Status */}
          {generateMutation.isPending && (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-orange-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-gray-600">Illusztráció generálása folyamatban...</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button variant="outline" onClick={handleClose}>
              {generatedImageUrl ? "Bezárás" : "Mégse"}
            </Button>
            <Button 
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Wand2 className="mr-2 h-4 w-4" />
              {generateMutation.isPending ? "Generálás..." : "Generálás"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
