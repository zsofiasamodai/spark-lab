import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, Keyboard, Image as ImageIcon, Upload, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { createWorker } from 'tesseract.js';

interface TaskUploadProps {
  taskData: {
    originalText: string;
    transformedText: string;
    promptUsed: string;
    illustrationUrl: string;
    name: string;
    folderId: string | null;
  };
  updateTaskData: (updates: Partial<TaskUploadProps['taskData']>) => void;
  onNext: () => void;
}

export default function TaskUpload({ taskData, updateTaskData, onNext }: TaskUploadProps) {
  const [activeTab, setActiveTab] = useState<"text" | "image">("text");
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewText, setPreviewText] = useState(taskData.originalText);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleTextChange = (text: string) => {
    setPreviewText(text);
    updateTaskData({ originalText: text });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type and size
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      toast({
        title: "Hibás fájltípus",
        description: "Csak JPG, PNG fájlok támogatottak.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB
      toast({
        title: "Túl nagy fájl",
        description: "A fájl mérete nem lehet nagyobb 10MB-nál.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      toast({
        title: "OCR feldolgozás",
        description: "Szöveg felismerés folyamatban...",
      });

      const worker = await createWorker('hun');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();

      const cleanedText = text.trim();
      if (cleanedText.length < 10) {
        toast({
          title: "Nem sikerült felismerni a szöveget",
          description: "Kérjük, próbálja meg tisztább képpel vagy írja be manuálisan.",
          variant: "destructive",
        });
      } else {
        setPreviewText(cleanedText);
        updateTaskData({ originalText: cleanedText });
        toast({
          title: "Sikeres feldolgozás",
          description: "A szöveg sikeresen felismerve!",
        });
      }
    } catch (error) {
      console.error("OCR error:", error);
      toast({
        title: "Feldolgozási hiba",
        description: "Nem sikerült feldolgozni a képet. Próbálja meg újra.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const canContinue = previewText.trim().length >= 50;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Upload Options */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Feladat Feltöltése
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Tab Navigation */}
          <div className="flex space-x-4 mb-6 border-b border-gray-200">
            <button
              onClick={() => setActiveTab("text")}
              className={`pb-2 px-1 border-b-2 font-medium transition-colors ${
                activeTab === "text"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <Keyboard className="inline mr-2 h-4 w-4" />
              Szöveg
            </button>
            <button
              onClick={() => setActiveTab("image")}
              className={`pb-2 px-1 border-b-2 font-medium transition-colors ${
                activeTab === "image"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <ImageIcon className="inline mr-2 h-4 w-4" />
              Kép
            </button>
          </div>

          {/* Text Input */}
          {activeTab === "text" && (
            <div className="space-y-4">
              <Textarea
                placeholder="Illessze be vagy írja be a feladat szövegét ide..."
                value={previewText}
                onChange={(e) => handleTextChange(e.target.value)}
                className="min-h-48 resize-none"
              />
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">
                  Minimum 50 karakter szükséges
                </span>
                <span className="text-sm text-gray-500">
                  {previewText.length} / 5000
                </span>
              </div>
            </div>
          )}

          {/* Image Upload */}
          {activeTab === "image" && (
            <div className="space-y-4">
              <div 
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 mb-2">
                  Húzza ide a képet vagy kattintson a tallózáshoz
                </p>
                <p className="text-sm text-gray-500">
                  JPG, PNG • Max 10MB
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept=".jpg,.jpeg,.png"
                  onChange={handleFileUpload}
                />
              </div>
              
              {/* OCR Processing Status */}
              {isProcessing && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <div className="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                    <span className="text-blue-700">
                      Szöveg felismerés folyamatban...
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Preview Section */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">
            Előnézet
          </CardTitle>
          {previewText && (
            <Button 
              variant="ghost" 
              size="sm"
              className="text-blue-600 hover:text-blue-700"
            >
              <FileText className="mr-1 h-4 w-4" />
              Szerkesztés
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <div className="min-h-48 border border-gray-200 rounded-lg p-4 bg-gray-50">
            {previewText ? (
              <div className="whitespace-pre-wrap text-gray-800">
                {previewText}
              </div>
            ) : (
              <p className="text-gray-500 italic text-center py-8">
                A feltöltött feladat szövege itt jelenik meg szerkeszthető formában...
              </p>
            )}
          </div>
          
          <div className="mt-4 flex justify-end">
            <Button 
              onClick={onNext}
              disabled={!canContinue}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Tovább 
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
