import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { FolderOpen, Edit, Trash2, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Folder } from "@shared/schema";

export default function FolderManagement() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState<Folder | null>(null);
  const [folderName, setFolderName] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch folders
  const { data: folders, isLoading, error: foldersError } = useQuery<Folder[]>({
    queryKey: ["/api/folders"],
  });

  // Handle folders error
  useEffect(() => {
    if (foldersError && isUnauthorizedError(foldersError as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [foldersError, toast]);

  // Create folder mutation
  const createFolderMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await apiRequest("POST", "/api/folders", { name });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setShowCreateDialog(false);
      setFolderName("");
      toast({
        title: "Mappa létrehozva",
        description: "A mappa sikeresen létrehozva!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Hiba",
        description: "Nem sikerült létrehozni a mappát.",
        variant: "destructive",
      });
    },
  });

  // Update folder mutation
  const updateFolderMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const response = await apiRequest("PUT", `/api/folders/${id}`, { name });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setShowEditDialog(false);
      setSelectedFolder(null);
      setFolderName("");
      toast({
        title: "Mappa frissítve",
        description: "A mappa neve sikeresen módosítva!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Hiba",
        description: "Nem sikerült frissíteni a mappát.",
        variant: "destructive",
      });
    },
  });

  // Delete folder mutation
  const deleteFolderMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/folders/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setShowDeleteDialog(false);
      setSelectedFolder(null);
      toast({
        title: "Mappa törölve",
        description: "A mappa sikeresen törölve!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Hiba",
        description: "Nem sikerült törölni a mappát.",
        variant: "destructive",
      });
    },
  });

  const handleCreateFolder = () => {
    if (!folderName.trim()) {
      toast({
        title: "Hibás mappa név",
        description: "A mappa neve nem lehet üres.",
        variant: "destructive",
      });
      return;
    }
    createFolderMutation.mutate(folderName.trim());
  };

  const handleEditFolder = () => {
    if (!selectedFolder || !folderName.trim()) {
      toast({
        title: "Hibás mappa név",
        description: "A mappa neve nem lehet üres.",
        variant: "destructive",
      });
      return;
    }
    updateFolderMutation.mutate({ id: selectedFolder.id, name: folderName.trim() });
  };

  const handleDeleteFolder = () => {
    if (!selectedFolder) return;
    deleteFolderMutation.mutate(selectedFolder.id);
  };

  const openEditDialog = (folder: Folder) => {
    setSelectedFolder(folder);
    setFolderName(folder.name);
    setShowEditDialog(true);
  };

  const openDeleteDialog = (folder: Folder) => {
    setSelectedFolder(folder);
    setShowDeleteDialog(true);
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
        <p className="text-gray-600">Mappák betöltése...</p>
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Mappák kezelése</CardTitle>
          <Button 
            onClick={() => setShowCreateDialog(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="mr-2 h-4 w-4" />
            Új mappa
          </Button>
        </CardHeader>
        <CardContent>
          {folders?.length ? (
            <div className="space-y-2">
              {folders.map((folder) => (
                <div 
                  key={folder.id}
                  className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg border border-gray-200"
                >
                  <div className="flex items-center space-x-3">
                    <FolderOpen className="text-gray-400 h-5 w-5" />
                    <div>
                      <span className="font-medium text-gray-900">{folder.name}</span>
                      <p className="text-sm text-gray-500">
                        Létrehozva: {new Date(folder.createdAt!).toLocaleDateString('hu-HU')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => openEditDialog(folder)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => openDeleteDialog(folder)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <FolderOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500">Még nincs létrehozott mappa</p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="mt-4 bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="mr-2 h-4 w-4" />
                Első mappa létrehozása
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Folder Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Új mappa létrehozása</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Mappa neve"
              value={folderName}
              onChange={(e) => setFolderName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreateFolder()}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Mégse
            </Button>
            <Button 
              onClick={handleCreateFolder}
              disabled={createFolderMutation.isPending}
            >
              Létrehozás
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Folder Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mappa átnevezése</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Új mappa név"
              value={folderName}
              onChange={(e) => setFolderName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleEditFolder()}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Mégse
            </Button>
            <Button 
              onClick={handleEditFolder}
              disabled={updateFolderMutation.isPending}
            >
              Mentés
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Folder Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mappa törlése</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600">
              Biztosan törölni szeretné a(z) <strong>"{selectedFolder?.name}"</strong> mappát? 
              Ez a művelet nem vonható vissza.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Mégse
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteFolder}
              disabled={deleteFolderMutation.isPending}
            >
              Törlés
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
