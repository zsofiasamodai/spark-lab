import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FolderOpen, Plus, Check, Save, Eye, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLocation } from "wouter";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Folder } from "@shared/schema";

interface TaskSaveProps {
  taskData: {
    originalText: string;
    transformedText: string;
    promptUsed: string;
    illustrationUrl: string;
    name: string;
    folderId: string | null;
  };
  updateTaskData: (updates: Partial<TaskSaveProps['taskData']>) => void;
}

export default function TaskSave({ taskData, updateTaskData }: TaskSaveProps) {
  const [taskName, setTaskName] = useState(
    taskData.name || 
    (taskData.transformedText ? "Átalakított feladat" : "Új feladat") + 
    " - " + new Date().toLocaleDateString('hu-HU')
  );
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(taskData.folderId);
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  // Fetch folders
  const { data: folders, error: foldersError } = useQuery<Folder[]>({
    queryKey: ["/api/folders"],
  });

  // Handle folders error
  useEffect(() => {
    if (foldersError && isUnauthorizedError(foldersError as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [foldersError, toast]);

  // Create folder mutation
  const createFolderMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await apiRequest("POST", "/api/folders", { name });
      return response.json();
    },
    onSuccess: (newFolder) => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setSelectedFolderId(newFolder.id);
      setShowCreateFolder(false);
      setNewFolderName("");
      toast({
        title: "Mappa létrehozva",
        description: `"${newFolder.name}" mappa sikeresen létrehozva!`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Hiba",
        description: "Nem sikerült létrehozni a mappát.",
        variant: "destructive",
      });
    },
  });

  // Save task mutation
  const saveTaskMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tasks", {
        name: taskName,
        originalText: taskData.originalText,
        transformedText: taskData.transformedText || null,
        promptUsed: taskData.promptUsed || null,
        illustrationUrl: taskData.illustrationUrl || null,
        folderId: selectedFolderId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setSaveSuccess(true);
      toast({
        title: "Feladat mentve",
        description: "A feladat sikeresen elmentve!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Mentési hiba",
        description: "Nem sikerült menteni a feladatot.",
        variant: "destructive",
      });
    },
  });

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) {
      toast({
        title: "Hibás mappa név",
        description: "A mappa neve nem lehet üres.",
        variant: "destructive",
      });
      return;
    }

    await createFolderMutation.mutateAsync(newFolderName.trim());
  };

  const handleSaveTask = async () => {
    if (!taskName.trim()) {
      toast({
        title: "Hibás feladat név",
        description: "A feladat neve nem lehet üres.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    try {
      await saveTaskMutation.mutateAsync();
    } finally {
      setIsSaving(false);
    }
  };

  const selectedFolder = folders?.find(f => f.id === selectedFolderId);

  if (saveSuccess) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="text-green-600 text-2xl" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Feladat Sikeresen Mentve!
        </h3>
        <p className="text-gray-600 mb-6">
          A feladat elmentve{selectedFolder ? ` a "${selectedFolder.name}" mappába` : ""}.
        </p>
        <div className="flex justify-center space-x-4">
          <Button 
            onClick={() => setLocation("/create-task")}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Új Feladat Létrehozása
          </Button>
          <Button 
            variant="outline"
            onClick={() => setLocation("/")}
          >
            Vissza a Dashboardra
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Folder Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Mentés Mappába
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Folder Tree */}
          <div className="space-y-2 max-h-64 overflow-y-auto border border-gray-200 rounded-lg p-4">
            {folders?.length ? (
              folders.map((folder) => (
                <div 
                  key={folder.id}
                  onClick={() => setSelectedFolderId(folder.id)}
                  className={`flex items-center space-x-2 p-2 hover:bg-gray-50 rounded cursor-pointer ${
                    selectedFolderId === folder.id 
                      ? 'bg-blue-50 border border-blue-200' 
                      : ''
                  }`}
                >
                  <FolderOpen className={`${
                    selectedFolderId === folder.id ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <span className={`font-medium flex-1 ${
                    selectedFolderId === folder.id ? 'text-blue-700' : 'text-gray-900'
                  }`}>
                    {folder.name}
                  </span>
                  {selectedFolderId === folder.id && (
                    <Check className="text-blue-600 h-4 w-4" />
                  )}
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">
                Még nincs létrehozott mappa
              </p>
            )}
          </div>

          {/* New Folder Option */}
          {showCreateFolder ? (
            <div className="space-y-2">
              <Input
                placeholder="Új mappa neve"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCreateFolder()}
              />
              <div className="flex space-x-2">
                <Button 
                  size="sm"
                  onClick={handleCreateFolder}
                  disabled={createFolderMutation.isPending}
                >
                  Létrehozás
                </Button>
                <Button 
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setShowCreateFolder(false);
                    setNewFolderName("");
                  }}
                >
                  Mégse
                </Button>
              </div>
            </div>
          ) : (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowCreateFolder(true)}
              className="text-blue-600 hover:text-blue-700"
            >
              <Plus className="h-4 w-4 mr-1" />
              Új mappa létrehozása
            </Button>
          )}

          {/* Task Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Feladat neve
            </label>
            <Input 
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              placeholder="Adja meg a feladat nevét"
            />
          </div>

          <Button 
            onClick={handleSaveTask}
            disabled={isSaving || !taskName.trim()}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Mentés..." : "Feladat Mentése"}
          </Button>
        </CardContent>
      </Card>

      {/* Final Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Végső Előnézet
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Task Content */}
          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 max-h-48 overflow-y-auto">
            <h4 className="font-medium text-gray-900 mb-2">{taskName}</h4>
            <div className="prose prose-sm max-w-none text-gray-700 prose-headings:text-gray-900 prose-strong:text-gray-900">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {taskData.transformedText || taskData.originalText}
              </ReactMarkdown>
            </div>
          </div>

          {/* Generated Illustration */}
          {taskData.illustrationUrl && (
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">
                Generált illusztráció:
              </h4>
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 text-center">
                <img 
                  src={taskData.illustrationUrl}
                  alt="Generált illusztráció a feladathoz" 
                  className="rounded-lg mx-auto mb-2 max-w-full max-h-32 object-contain"
                />
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="text-blue-600 hover:text-blue-700"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = taskData.illustrationUrl;
                    link.download = `${taskName}-illustration.png`;
                    link.click();
                  }}
                >
                  <Download className="mr-1 h-4 w-4" />
                  Letöltés
                </Button>
              </div>
            </div>
          )}

          {/* Metadata */}
          <div className="text-sm text-gray-500 space-y-1">
            <p>
              <strong>Mappa:</strong> {selectedFolder?.name || "Nincs kiválasztva"}
            </p>
            <p>
              <strong>Létrehozva:</strong> {new Date().toLocaleDateString('hu-HU')}
            </p>
            {taskData.transformedText && (
              <p><strong>AI modell:</strong> GPT-4</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
