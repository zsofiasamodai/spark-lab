import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowRight, Wand2, RotateCcw, Edit, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import IllustrationModal from "@/components/illustration-modal";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Prompt } from "@shared/schema";

interface AITransformationProps {
  taskData: {
    originalText: string;
    transformedText: string;
    promptUsed: string;
    illustrationUrl: string;
    name: string;
    folderId: string | null;
  };
  updateTaskData: (updates: Partial<AITransformationProps['taskData']>) => void;
  onNext: () => void;
}

export default function AITransformation({ taskData, updateTaskData, onNext }: AITransformationProps) {
  const [customPrompt, setCustomPrompt] = useState(taskData.promptUsed || "");
  const [selectedPromptId, setSelectedPromptId] = useState<string>("");
  const [shouldSavePrompt, setShouldSavePrompt] = useState(false);
  const [promptName, setPromptName] = useState("");
  const [includeRealLifeExamples, setIncludeRealLifeExamples] = useState(false);
  const [isTransforming, setIsTransforming] = useState(false);
  const [showIllustrationModal, setShowIllustrationModal] = useState(false);
  const { toast } = useToast();

  // Fetch saved prompts
  const { data: prompts, error: promptsError } = useQuery<Prompt[]>({
    queryKey: ["/api/prompts"],
  });

  // Handle prompts error
  useEffect(() => {
    if (promptsError && isUnauthorizedError(promptsError as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [promptsError, toast]);

  // Transform task mutation
  const transformMutation = useMutation({
    mutationFn: async ({ originalText, context, includeExamples }: { originalText: string; context: string; includeExamples?: boolean }) => {
      const response = await apiRequest("POST", "/api/tasks/transform", {
        originalText,
        context,
        includeRealLifeExamples: includeExamples,
      });
      return response.json();
    },
    onSuccess: (data) => {
      updateTaskData({ 
        transformedText: data.transformedText,
        promptUsed: customPrompt 
      });
      toast({
        title: "Sikeres átalakítás",
        description: "A feladat sikeresen átalakítva!",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      // Parse error message for better user feedback
      const errorMessage = error.message || "";
      let title = "Átalakítási hiba";
      let description = "Nem sikerült átalakítani a feladatot. Próbálja meg újra.";
      
      if (errorMessage.includes("429:")) {
        title = "API kvóta kimerült";
        description = "Az OpenAI API kvóta kimerült. Kérjük, ellenőrizze a számlázási adatokat, vagy próbálja meg később.";
      } else if (errorMessage.includes("quota")) {
        title = "API kvóta kimerült";
        description = "Az AI szolgáltatás kvótája kimerült. Próbálja meg később vagy ellenőrizze az API beállításokat.";
      } else if (errorMessage.includes("503:") || errorMessage.includes("SERVICE_UNAVAILABLE")) {
        title = "Szolgáltatás nem elérhető";
        description = "Az AI szolgáltatás átmenetileg nem elérhető. Próbálja meg néhány perc múlva.";
      } else if (errorMessage.includes("401:") || errorMessage.includes("INVALID_API_KEY")) {
        title = "API kulcs hiba";
        description = "Az API kulcs érvénytelen vagy lejárt. Kérjük, ellenőrizze a beállításokat.";
      }
      
      toast({
        title,
        description,
        variant: "destructive",
      });
    },
  });

  // Save prompt mutation
  const savePromptMutation = useMutation({
    mutationFn: async ({ name, content }: { name: string; content: string }) => {
      const response = await apiRequest("POST", "/api/prompts", { name, content });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prompt mentve",
        description: "A prompt sikeresen elmentve!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Mentési hiba",
        description: "Nem sikerült menteni a promptot.",
        variant: "destructive",
      });
    },
  });

  const handlePromptSelect = (promptId: string) => {
    setSelectedPromptId(promptId);
    const selectedPrompt = prompts?.find(p => p.id === promptId);
    if (selectedPrompt) {
      setCustomPrompt(selectedPrompt.content);
    }
  };

  const handleTransform = async () => {
    if (!customPrompt.trim() || customPrompt.length < 10 || customPrompt.length > 1000) {
      toast({
        title: "Hibás prompt",
        description: "A prompt 10-1000 karakter között kell legyen.",
        variant: "destructive",
      });
      return;
    }

    setIsTransforming(true);
    
    try {
      await transformMutation.mutateAsync({
        originalText: taskData.originalText,
        context: customPrompt,
        includeExamples: includeRealLifeExamples,
      });

      // Save prompt if requested
      if (shouldSavePrompt && promptName.trim()) {
        await savePromptMutation.mutateAsync({
          name: promptName.trim(),
          content: customPrompt,
        });
      }
    } finally {
      setIsTransforming(false);
    }
  };

  const canTransform = customPrompt.trim().length >= 10 && customPrompt.trim().length <= 1000;
  const canContinue = taskData.transformedText.trim().length > 0;

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Prompt Input */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Kontextus Megadása
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Saved Prompts */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mentett promptok
              </label>
              <Select value={selectedPromptId} onValueChange={handlePromptSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Válasszon mentett promptot..." />
                </SelectTrigger>
                <SelectContent>
                  {prompts?.map((prompt) => (
                    <SelectItem key={prompt.id} value={prompt.id}>
                      {prompt.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Custom Prompt */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Egyéni kontextus
              </label>
              <Textarea
                placeholder="Például: 'Írd át a feladatot Marvel szuperhősök témájára. A számadatok és a feladat lényege maradjon változatlan, csak a történet és szereplők változzanak.'"
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                className="h-32 resize-none"
              />
              
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm text-gray-500">10-1000 karakter között</span>
                <span className={`text-sm ${
                  customPrompt.length < 10 || customPrompt.length > 1000 
                    ? 'text-red-500' 
                    : 'text-gray-500'
                }`}>
                  {customPrompt.length} / 1000
                </span>
              </div>
            </div>

            {/* Real-life Examples Option */}
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="real-life-examples" 
                checked={includeRealLifeExamples}
                onCheckedChange={(checked) => setIncludeRealLifeExamples(checked as boolean)}
              />
              <label htmlFor="real-life-examples" className="text-sm text-gray-700">
                Valós életbeli alkalmazási példák hozzáadása
              </label>
            </div>

            {/* Save Prompt Option */}
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="save-prompt" 
                  checked={shouldSavePrompt}
                  onCheckedChange={(checked) => setShouldSavePrompt(checked as boolean)}
                />
                <label htmlFor="save-prompt" className="text-sm text-gray-700">
                  Prompt mentése későbbi használatra
                </label>
              </div>
              
              {shouldSavePrompt && (
                <input
                  type="text"
                  placeholder="Prompt neve"
                  value={promptName}
                  onChange={(e) => setPromptName(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              )}
            </div>

            <Button 
              onClick={handleTransform}
              disabled={!canTransform || isTransforming}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Wand2 className="mr-2 h-4 w-4" />
              {isTransforming ? "Átalakítás..." : "AI Átalakítás Indítása"}
            </Button>
          </CardContent>
        </Card>

        {/* AI Processing & Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Átalakított Feladat
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Processing State */}
            {isTransforming && (
              <div className="text-center py-12">
                <div className="animate-spin w-12 h-12 border-4 border-green-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-gray-600 mb-2">AI feldolgozás folyamatban...</p>
                <p className="text-sm text-gray-500">Ez általában 10-30 másodpercig tart</p>
              </div>
            )}

            {/* Result Preview */}
            {!isTransforming && taskData.transformedText && (
              <div>
                <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 mb-4 max-h-64 overflow-y-auto">
                  <div className="prose prose-sm max-w-none text-gray-800 prose-headings:text-gray-900 prose-strong:text-gray-900">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {taskData.transformedText}
                    </ReactMarkdown>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={handleTransform}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <RotateCcw className="mr-1 h-4 w-4" />
                      Újragenerálás
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Edit className="mr-1 h-4 w-4" />
                      Szerkesztés
                    </Button>
                  </div>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => setShowIllustrationModal(true)}
                      className="bg-orange-600 hover:bg-orange-700"
                      size="sm"
                    >
                      <ImageIcon className="mr-2 h-4 w-4" />
                      Illusztráció
                    </Button>
                    <Button 
                      onClick={onNext}
                      disabled={!canContinue}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Mentés 
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Empty State */}
            {!isTransforming && !taskData.transformedText && (
              <div className="text-center py-12">
                <p className="text-gray-500 italic">
                  Az átalakított feladat itt fog megjelenni az AI feldolgozás után...
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <IllustrationModal
        isOpen={showIllustrationModal}
        onClose={() => setShowIllustrationModal(false)}
        taskText={taskData.transformedText || taskData.originalText}
        onIllustrationGenerated={(url) => updateTaskData({ illustrationUrl: url })}
      />
    </>
  );
}
