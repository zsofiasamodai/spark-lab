import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

export default function QuotaWarning() {
  return (
    <Alert className="mb-6 border-orange-200 bg-orange-50 text-orange-800">
      <AlertTriangle className="h-4 w-4 text-orange-600" />
      <AlertTitle className="text-orange-800">API Kvóta Figyelmeztetés</AlertTitle>
      <AlertDescription className="text-orange-700">
        Az OpenAI API kvóta jelenleg kimerült. Ez azt jelenti, hogy:
        <ul className="mt-2 ml-4 list-disc space-y-1">
          <li>Az AI-alapú feladat átalakítás átmenetileg nem elérhető</li>
          <li>Az illusztráció generálás szintén korlátozva van</li>
          <li>Az API kulcs tulajdonosának fel kell töltenie a számlát az OpenAI oldalon</li>
        </ul>
        <div className="mt-3 text-sm">
          <strong>Mit tehet:</strong>
          <br />
          • Ellenőrizze az OpenAI fiók számlázási beállításait
          <br />
          • Várjon néhány órát/napot a kvóta újratöltődésére
          <br />
          • Próbálja meg később a funkciók használatát
        </div>
      </AlertDescription>
    </Alert>
  );
}