import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Wand2, FolderOpen, Users } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-xl font-semibold text-gray-900">StoryTask</h1>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Bejelentkezés
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Alakítsa át feladatait
            <span className="block text-blue-600">AI segítségével</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            A StoryTask segítségével egyszerűen átalakíthatja meglévő tankönyvi feladatait 
            új kontextusba, miközben megőrzi a matematikai tartalmat és tanulási célokat.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
          >
            Kezdjen el most
          </Button>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Miért válassza a StoryTaskot?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Innovatív eszközök tanárok számára a feladatok kreatív átalakításához
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="text-center border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Egyszerű feltöltés
              </h3>
              <p className="text-gray-600 text-sm">
                Szöveg vagy kép formájában feltöltheti a feladatokat OCR támogatással
              </p>
            </CardContent>
          </Card>

          <Card className="text-center border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Wand2 className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                AI átalakítás
              </h3>
              <p className="text-gray-600 text-sm">
                GPT-4 technológia a feladatok kreatív átírásához új kontextusban
              </p>
            </CardContent>
          </Card>

          <Card className="text-center border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <FolderOpen className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Rendezett tárolás
              </h3>
              <p className="text-gray-600 text-sm">
                Mappákba rendezheti a feladatokat egyszerű kereshetőséggel
              </p>
            </CardContent>
          </Card>

          <Card className="text-center border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Tanár-központú
              </h3>
              <p className="text-gray-600 text-sm">
                Kifejezetten oktatók igényeire szabott felhasználói élmény
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-4">
            Kezdje el még ma!
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Csatlakozzon több száz tanárhoz, akik már használják a StoryTaskot
          </p>
          <Button 
            size="lg"
            variant="secondary"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-blue-600 hover:bg-blue-50 text-lg px-8 py-3"
          >
            Regisztrálok most
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <BookOpen className="h-6 w-6 text-blue-600" />
            <span className="text-lg font-semibold text-gray-900">StoryTask</span>
          </div>
          <p className="text-gray-600">
            © 2024 StoryTask. Minden jog fenntartva.
          </p>
        </div>
      </footer>
    </div>
  );
}
