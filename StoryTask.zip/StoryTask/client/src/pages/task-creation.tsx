import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import TaskUpload from "@/components/task-upload";
import AITransformation from "@/components/ai-transformation";
import TaskSave from "@/components/task-save";

export default function TaskCreation() {
  const { isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [taskData, setTaskData] = useState({
    originalText: "",
    transformedText: "",
    promptUsed: "",
    illustrationUrl: "",
    name: "",
    folderId: null as string | null,
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Betöltés...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const updateTaskData = (updates: Partial<typeof taskData>) => {
    setTaskData(prev => ({ ...prev, ...updates }));
  };

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const steps = [
    { number: 1, title: "Feladat Feltöltése", active: currentStep >= 1, completed: currentStep > 1 },
    { number: 2, title: "AI Átalakítás", active: currentStep >= 2, completed: currentStep > 2 },
    { number: 3, title: "Mentés", active: currentStep >= 3, completed: false },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <BookOpen className="text-blue-600 text-2xl" />
                <h1 className="text-xl font-semibold text-gray-900">StoryTask</h1>
              </div>
            </div>
            <Link href="/">
              <Button variant="ghost" className="text-gray-500 hover:text-gray-700">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Vissza
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Indicator */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Új Feladat Létrehozása</h2>
            </div>
            
            <div className="flex items-center space-x-4">
              {steps.map((step, index) => (
                <div key={step.number} className="flex items-center">
                  <div className="flex items-center space-x-2">
                    <div 
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                        step.completed 
                          ? 'bg-green-500 text-white' 
                          : step.active 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-200 text-gray-500'
                      }`}
                    >
                      {step.number}
                    </div>
                    <span 
                      className={`font-medium ${
                        step.active ? 'text-gray-900' : 'text-gray-500'
                      }`}
                    >
                      {step.title}
                    </span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className="flex-1 h-1 bg-gray-200 rounded ml-4 mr-4 w-16">
                      <div 
                        className={`h-1 rounded ${
                          step.completed ? 'bg-green-500' : step.active ? 'bg-blue-600 w-1/3' : 'bg-gray-200'
                        }`}
                        style={{ 
                          width: step.completed ? '100%' : step.active ? '33%' : '0%' 
                        }}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Step Content */}
        {currentStep === 1 && (
          <TaskUpload 
            taskData={taskData}
            updateTaskData={updateTaskData}
            onNext={nextStep}
          />
        )}

        {currentStep === 2 && (
          <AITransformation 
            taskData={taskData}
            updateTaskData={updateTaskData}
            onNext={nextStep}
          />
        )}

        {currentStep === 3 && (
          <TaskSave 
            taskData={taskData}
            updateTaskData={updateTaskData}
          />
        )}
      </div>
    </div>
  );
}
