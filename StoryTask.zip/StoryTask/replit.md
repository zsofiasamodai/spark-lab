# StoryTask - AI-Powered Educational Task Transformer

## Overview

StoryTask is a web application designed for primary and secondary school teachers to transform existing textbook exercises using AI assistance. The application allows teachers to upload tasks (text or images), apply AI transformations to change narrative context while preserving mathematical content, generate illustrations, and organize tasks in folders. The system maintains the educational integrity of exercises while making them more engaging through contextual transformation (e.g., converting standard math problems to Marvel-themed scenarios).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom educational color scheme and Hungarian language support
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL session store
- **File Upload**: Multer middleware for handling multipart/form-data

### Database Design
- **Database**: PostgreSQL with Neon serverless connection
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Tables**:
  - `users`: User profiles with Replit Auth integration
  - `folders`: Hierarchical task organization
  - `prompts`: Reusable AI transformation prompts
  - `tasks`: Core task entities with original/transformed content
  - `sessions`: Session storage for authentication

### AI Integration
- **Provider**: OpenAI GPT-4o-mini for cost-efficient text transformation (60% cheaper than previous models)
- **Image Generation**: OpenAI DALL-E-3 for educational illustrations
- **OCR Processing**: Tesseract.js for client-side image text extraction
- **Content Preservation**: AI prompts specifically designed to maintain mathematical accuracy while transforming narrative context
- **Error Handling**: Comprehensive quota and API error management with Hungarian language user feedback

### Authentication & Security
- **Authentication**: Replit's OpenID Connect implementation
- **Session Security**: HTTP-only cookies with secure settings
- **Authorization**: Role-based access with teacher permissions
- **CORS**: Configured for development and production environments

### File Processing
- **Image Upload**: Client-side OCR processing with Tesseract.js
- **File Validation**: Type and size restrictions (JPG, PNG, 10MB limit)
- **Text Extraction**: Automatic conversion of uploaded images to editable text

### Development Workflow
- **Build System**: Vite for frontend, esbuild for backend bundling
- **Development**: Hot module replacement with Vite dev server
- **Type Safety**: Shared TypeScript types between frontend and backend
- **Code Organization**: Modular structure with clear separation of concerns

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection with WebSocket support
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **express**: Web application framework with session management
- **openai**: Official OpenAI API client for GPT-4o and DALL-E integration

### UI Framework
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **@tanstack/react-query**: Server state management and data fetching
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Modern icon library

### Authentication
- **openid-client**: OpenID Connect client implementation
- **passport**: Authentication middleware
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **zod**: Runtime type validation and schema definition
- **tesseract.js**: Client-side OCR processing

### File Processing
- **multer**: Multipart file upload handling
- **ws**: WebSocket library for Neon database connection